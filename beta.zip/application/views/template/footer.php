<div class="footerContainer">
<div class="col-md-3"></div>
			<div class="sitemap">
				<h4>Information</h4>
				<p class="caption">
					<a href="#" >What We Offer</a>
                                        <br>
					<a href="#">Help and FAQ</a>
					<br>
					<a href="#">Feedback Program</a>
				</p>
			</div>
			<div class="sitemap">
				<h4>Community</h4>
				<p class="caption">
                                    <a href="http://www.tech.net.np" target="_blank">Blog</a>
					<br>
					<a href="#">Meetups</a>
					<br>
					<a href="#">News &amp; Media</a>
				</p>
			</div>
			<div class="sitemap">
				<h4>Reservation</h4>
				<p class="caption">
					<a href="#">About</a>
					<br>
					<a href="#">Codes</a>
					<br>
					<a href="#">Contact Us</a>
					<br>
					<a href="#">Terms of Use</a>
					<br>
					<a href="#">Privacy Statements</a>
				</p>
			</div>
			<div class="sitemap">
				<h4>Follow us on</h4>
				<a href="https://www.facebook.com/salyani"><img style="width:30px; height:30px; border-radius: 20px;" src=<?php echo base_url().'contents/images/facebook1.jpg'; ?>  /></span></a>
                                <a href="#"  /><img style="width:30px; height:30px; border-radius: 20px;" src=<?php echo base_url().'contents/images/google1.jpg'; ?>  /></a>
				<a href="#"><img style="width:30px; height:30px; border-radius: 20px;" src=<?php echo base_url().'contents/images/twitter.jpg'; ?>  /></span></a>
				<a href="#"><img style="width:30px; height:30px; border-radius: 20px;" src=<?php echo base_url().'contents/images/in.jpg'; ?>  /></span></a>
				<div class="row row-gap-medium">
					<div class="col-md-12 text-muted">&copy; 2014 Reservation</div>
				</div>
			</div>
</div>
<div class="clear"></div> 
</body>
</html>