<div class="container">
   
          <!-- hitwebcounter Code START -->
        
        <p class="footerLeft" >&COPY; all rights reserved. 2014 salyani technologies.</p>

<p class="footerLeft">Page view:<a  href="http://salyani.com.np/" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=5295345&style=0030&nbdigits=5&type=ip&initCount=0" title="Visitors Counter" Alt="Visitors Counter"   border="0" >
</a>&nbsp;&nbsp;&nbsp;Page rendered in <strong>{elapsed_time}</strong> seconds</p>  

</div>

</body>
</html>