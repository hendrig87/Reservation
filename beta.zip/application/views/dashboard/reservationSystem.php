<?php 


?>
<div id="main">
<div id="left">
<div id="navigation">
    <ul>
        <li><h2>Reservation</h2>
  
            <ul>
                <li><a href="<?php echo base_url().'index.php/dashboard/addNewRoomForm'; ?>">Add new room</a></li>
                <li><a href="<?php echo base_url().'index.php/login/calender'; ?>">Calender</a></li>
                <li>Booking</li>
                <li><a href="<?php echo base_url().'index.php/dashboard/booking'; ?>">Rooms</a></li>
            </ul>
       
             </li>
             
             <li><h2>Documentation</h2></li>     
    </ul>
</div>
</div>
    