<?php
    
    function get_currency($data)
    {
         echo 'Rs.'.$data.".00";   
    }
