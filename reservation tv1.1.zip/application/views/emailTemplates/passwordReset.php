<div style="padding: 10px 20px 10px 20px; background-color: #eee;">
    <h3>Reservation password reset</h3>
    <h4>dear  !</h4>
    <p>Click <a href="'.$uri.'/reset.php?token='.$token.'"> here</a> to reset your password.</p>
    <p>Regards</p>
    <p>Reservation</p>
    
</div>