<div class="right">
    
    <h2>Calender</h2><hr class="topLine" />
    
</div>
<div id="clear"></div>
</div>