<div class="right">
<h2>Frequently Asked Questions</h2>
<hr>
<h4>Table of Contents</h4>
<p> 1. What is reservation system?</p>

<p> 2. I am a Hotel Owner. How is it beneficial to me?</p>

<p>3. Is it free for lodges?</p>
<p> 2. I am a user. How is it beneficial to me?</p>
<p>4. Is it free for users?</p>

<p>5. Where can I find listing of the best lodges?</p>

<p>6. I know the name/location/phone of the lodge, but how can I book that lodge from my current location?</p>

<p>What is reservation system?</p>
<p>reservation System is the service model made to make your booking easy.</p>
<p>I am a Hotel Owner. How is it beneficial to me?</p>
<p>We are affiliate business for restaurants. Simply you can copy and paste code from our documentation to your web site html page and enable online booking for your visitors OR you can create your hotel in reservation , from where also your visitors can book your hotel.We give you customers when they are searching for lodges. So that you can increase your customers.</p>

<p> Is it free for lodges?</p>
<p>Definitely</p>

<p> I am a user. How is it beneficial to me?</p>
<p>Simply you can make booking to your favourite lodge just from your home/ workspace/street or from anywhere.</p>

<p>Is it free for users?</P>
<p>Always!</p>
<p>Where can I find listing of the best lodges?</p>
<p>Reservation system can help you find your favourite and best lodge in your desired location.</p>
<p>I know the name/location/phone of the lodge, but how can I book that lodge from my current location?</p>
<p>Using reservation system you can search your favourite lodge by its name, location, description or contact number and book rooms from your current place.</P>
</div>
<div id="clear"></div>
</div>