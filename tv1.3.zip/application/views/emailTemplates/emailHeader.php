        <div style="width: 750px; margin: 0 auto 0 auto; padding: 0px;" >
        <div style="display:table-cell; vertical-align:middle; text-align:center; height: 70px; width: 1000px; alignment-adjust: central; background-color: #ccc; margin: 0 auto 0 auto;">
            <img src="<?php echo base_url() . "contents/images/ParkReserve.png"; ?>" style="height: 50px; width: 50px; "/>

            </div>

   