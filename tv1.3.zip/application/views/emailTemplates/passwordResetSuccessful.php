<div style="padding: 10px 20px 10px 20px; background-color: #eee;">
    <h4>Dear  !</h4>
    <p>Your password is reseted successfully.</p>
</div>