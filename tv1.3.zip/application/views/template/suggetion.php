
<!DOCTYPE HTML>
<html>
    <head></head>
    <body>
        <div style="z-index: 500">
        <input type="text" name="searchBox" />
        </div>
        </body>
</html>