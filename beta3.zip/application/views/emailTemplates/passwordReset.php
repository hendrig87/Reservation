<div>
    <h4>Reservation password reset</h4>
    <p>dear  !</p>
    <p>Click <a href="'.$uri.'/reset.php?token='.$token.'"> here</a> to reset your password.</p>
    <p>Regards</p>
    <p>Reservation</p>
    
</div>