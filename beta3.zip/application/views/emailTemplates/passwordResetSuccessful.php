<div>
    <h4>Dear  !</h4>
    <p>Your password is reseted successfully.</p>
</div>