<html>
    <head>
    <title>Password reset link</title>
    </head>
    <body>
        <div style="height: 100px; alignment-adjust: central;">

                <img src="<?php echo base_url() . "contents/images/ParkReserve.png"; ?>"/>

            </div>

   