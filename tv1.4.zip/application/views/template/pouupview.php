<div class="event-popup" style="display: none; width: 300px; height: 300px; position: fixed; top:200px; left: 600px; z-index: 100; background-color: #10B0DA;">
   <a href="#" id="popUpClose">Close</a>
    <div id='replacable'></div>
</div>