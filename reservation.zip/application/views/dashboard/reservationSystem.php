<?php 


?>
<div id="main">
<div id="left">
<div id="navigation">
    <ul>
        <li id="show_arrow"><h2>Reservation</h2>
  
            <ul>
                <li id="reservation"><a href="<?php echo base_url().'index.php/hotels/index'; ?>">Add new hotel</a></li>
                <li id="reservation"><a href="<?php echo base_url().'index.php/dashboard/addNewRoomForm'; ?>">Add new room</a></li>
                <li id="reservation"><a href="<?php echo base_url().'index.php/dashboard/calender'; ?>">Calender</a></li>
                <li id="reservation"><a href="<?php echo base_url().'index.php/dashboard/bookingInfo'; ?>">Booking</a></li>
                <li id="reservation"><a href="<?php echo base_url().'index.php/dashboard/roomInfo'; ?>">Rooms</a></li>
            </ul>
       
             </li>
             
             <li><h2>Documentation</h2></li>     
    </ul>
</div>
</div>
    