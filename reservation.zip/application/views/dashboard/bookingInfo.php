<div id="right">
    
    <h2>Booking</h2><hr style="display: block; height: 1px;
    border: 0; border-top: 1px solid #ccc;
    margin: 1em 0; padding: 0;">
    
</div>
<div id="clear"></div>
</div>