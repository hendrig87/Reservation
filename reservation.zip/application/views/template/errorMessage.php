<div id="EmailSentMessage">
    <p id="sucessmsg">
            <?php if($this->session->flashdata('message'))echo $this->session->flashdata('message');
              ?> </p>
</div>