     <div id="topNavigationWithSlider">
<div class="centerDiv" id="sliderDescriptionDiv">
                <h2>Write something message</h2>
                <p>Write some message</p>
            </div>
        </div>