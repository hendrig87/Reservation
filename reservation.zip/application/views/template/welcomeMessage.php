<div >
    <h2 style="text-align: center">Welcome To Reservation System.</h2>
    
    
</div>