Reservation
===========

Online Reservation System 

###CONTROLLERS

WELCOME

This Controller is used to load the initial default view of reservation.

LOGIN

This controller mainly deals with login and registration. The methods in it are to register new user, to login existing user, to send email if user clicks on forgot password link. Similarly here we have method to logout too.

DASHBOARD

This controller is concerned with adding rooms, viewing rooms, editing and deleting rooms by the users who are using our product in their websites. 

ROOM_BOOKING

This controller deals with booking information of a hotel. Different methods here are responsible to add and show check in check out information, personal information payment options and finally to show thanking message to the visitor.


###VIEW FOLDERS

ReservationInformation

This folder contains the form to add personal information of checked user.

Dashboard

This folder inside view folder mainly contains the form to add room, edit and delete room by the hotels and showing the rooms as well.

Login

This folder inside view folder contains the forms to register, login and to reset the passwoord if needed.

Template

 Inside template folder the Header file is to load the view of top navigation along with navigation panel.
 The imageDiv file is to load the image in default view.
 Reservation_template file is to load the view for check in check out.
 The footer file is to load the footer content with sitemap navigations.
 
