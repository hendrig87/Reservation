<?php
    
    function get_currency($data)
    {
         echo '<span>Rs.</span>'.'<span class="priceTag">'.$data.'</span>'."<span>.00</span>";   
    }
