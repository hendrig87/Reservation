        <div style="width: 750px; margin: 0 auto 0 auto; padding: 0px;" >
        <div style="display:table-cell; vertical-align:middle; text-align:center; height: 70px; width: 1000px; alignment-adjust: central; background-color: #ccc; margin: 0 auto 0 auto;">
            <img src="<?php echo base_url() . "contents/images/ParkReserve.png"; ?>" style="height: 50px; width: 50px; "/>

            </div>

   <div style="padding: 10px 20px 10px 20px; background-color: #eee;">
   
    
    <h4>Dear hom nath !</h4>

    <h3>Welcome to reservation.</h3>
    <h4>Thank you for your booking through reservation. </h4>
    <p> You have booked hotel (hotel name) from (checkindate) to (checkout date) for (no of adults) and (no of childs)for (price).
        
        
    </p>
</div>
            
            <div style="display:table-cell; vertical-align:middle; text-align:center; height: 70px; width: 1000px; alignment-adjust: central; background-color: #ccc; margin: 0 auto 0 auto;">
           <p>&copy Reservation</p>

            </div>

</div>
 